
# coding: utf-8

# In[10]:

import numpy as np


# In[11]:

print("Enter 2 strings (Case Sensitive): ")

X = input()
Y = input()

# print(X)
# print(Y)

M = len(X)
N = len(Y)


# In[12]:

D = np.zeros((M+1, N+1), dtype=int)
ptr = np.array(["" for i in range((M+1)*(N+1))]).reshape((M+1, N+1))

# print(D)
# print(ptr)


# In[13]:

for i in range(M+1):
    D[i, 0] = i
    ptr[i, 0] = "U"

for j in range(N+1):
    D[0, j] = j
    ptr[0, j] = "L"


# In[14]:

#Edit Distance

for i in range(1, M+1):
    for j in range(1, N+1):
        if (D[i-1, j] + 1 < D[i, j-1] + 1):
            res = D[i-1, j] + 1
            ptr[i, j] = "U"
        else:
            res = D[i, j-1] + 1
            ptr[i, j] = "L"
        
        if (X[i-1] != Y[j-1]):
            if (D[i-1, j-1] + 2 < res):
                res = D[i-1, j-1] + 2
                ptr[i, j] = "D"
        else:
            if (D[i-1, j-1] < res):
                res = D[i-1, j-1]
                ptr[i, j] = "D"
        
        D[i, j] = res


# In[15]:

# print(D)
# print(ptr)


# In[16]:

print("Cost =", D[M][N])


# In[17]:

#Backtracking
i=M
j=N

ans = []

while (i>=0 and j>=0):
    if (i==0 and j==0):
        break
    if (ptr[i, j] == "D"):
        if (X[i-1] == Y[j-1]):
            ans += [[X[i-1], Y[j-1], "="]]
        else:
            ans += [[X[i-1], Y[j-1], "s"]]
        i-=1
        j-=1
    elif (ptr[i, j] == "U"):
        ans += [[X[i-1], "*", "d"]]
        i-=1
    elif (ptr[i, j] == "L"):
        ans += [["*", Y[j-1], "i"]]
        j-=1


# In[18]:

for i in range(len(ans)):
    for j in ans[len(ans)-i-1]:
        print(j, end=" ")
    print()

