
# coding: utf-8

# In[1]:

import os
import re
import json


# In[2]:

pwd = os.getcwd()
f = open(os.path.join(pwd, r'Development Set.txt'), 'r')
text = f.read()
f.close()


# In[3]:

#Count Number of Paragraphs
allParas = re.split('\n\n', text)

countPara = 0
paras = [] #List of all paragraphs
for para in allParas:
    if len(para) > 0:
        countPara += 1
        paras.append(para)

print("Number of Paragraphs: ")
print(countPara)


# In[4]:

#Count Number of Sentences
tokens = text.split()

countLines = 0
lines = [] #List of all Sentences
line = ""
flag = 0 #Checks if a sentence is completed (0->no, 1->yes)

for word in tokens:
    if flag == 1 and word[0].isupper() == True:
        lines.append(line)
        line = ""
        flag = 0

    if word.endswith('.') or word.endswith('!') or word.endswith('?') or word.endswith(';'):
        flag = 1

    if word.endswith('.') and word[0].isupper == True:
        flag = 0
        
    line += word + " "

if (line != ""):
    lines[-1] += line
    
mylines = []
print("Number of lines: ")
for line in lines:
    if (len(line) > 0):
        countLines += 1
        mylines.append(line)
        
lines = mylines
print(countLines)


# In[5]:

# i=0
# for line in lines:
#     i += 1
#     print(i, line, end='\n\n')


# In[6]:

#Count Number of Words
allWords = [] #List of all the words
for para in paras:
    p = para
    allWords += re.findall("[\w\-\.\']+", p) #find all words with hyphens(-), full stops(.) or apostrophe(')
    
countWords = 0
words = []
for word in allWords:
    w = word.lower().strip('.?!;:-')
    if len(w) > 0:
        countWords += 1
        words.append(w)

print("Number of Words: ")
print(countWords)


# In[7]:

#Dictionary of first words
firstWords = []
for line in lines:
    w = line.split()
    if (len(w) > 0):
        firstWords.append(w[0].lower().strip('.?!;:'))

fwdic = {}
for fw in firstWords:
    if fw not in fwdic:
        fwdic[fw] = 0
    fwdic[fw] += 1

fp = open(os.path.join(pwd, r'fwdic.json'), 'w+')
json.dump(fwdic, fp, sort_keys=True)
fp.close()


# In[8]:

fp = open(os.path.join(pwd, r'fwdic.json'), 'r')
fwdic = json.load(fp)
fp.close()

print("""Given a word as input, number of sentences starting with the word
Enter word (case insensitive) to find count: """)
inp = input()
inp = inp.lower().strip('.?!;:-')
if inp in fwdic:
    print(fwdic[inp])
else:
    print("Word not found")


# In[9]:

#Dictionary of last words
lastWords = []
for line in lines:
    w = line.split()
    if (len(w) > 0):
        lastWords.append(w[-1].lower().strip('.?!;:'))

lwdic = {}
for lw in lastWords:
    if lw not in lwdic:
        lwdic[lw] = 0
    lwdic[lw] += 1

fp = open(os.path.join(pwd, r'lwdic.json'), 'w+')
json.dump(lwdic, fp, sort_keys=True)
fp.close()


# In[10]:

fp = open(os.path.join(pwd, r'lwdic.json'), 'r')
lwdic = json.load(fp)
fp.close()

print("""Given a word as input, number of sentences ending with the word
Enter word (case insensitive) to find count: """)
inp = input()
inp = inp.lower().strip('.?!;:-')
if inp in lwdic:
    print(lwdic[inp])
else:
    print("Word not found")


# In[11]:

#Dictionary of all the words
worddic = {}
for word in words:
    w = word
    if (len(w) > 0):
        if w not in worddic:
            worddic[w] = 0
        worddic[w] += 1

fp = open(os.path.join(pwd, r'worddic.json'), 'w+')
json.dump(worddic, fp, sort_keys=True)
fp.close()


# In[12]:

fp = open(os.path.join(pwd, r'worddic.json'), 'r')
worddic = json.load(fp)
fp.close()

print("""Given a word as input, count of that word in the input file
Enter word (case insensitive) to find count: """)
inp = input()
inp = inp.lower().strip('.?!;:-')
if inp in worddic:
    print(worddic[inp])
else:
    print("Word not found")

