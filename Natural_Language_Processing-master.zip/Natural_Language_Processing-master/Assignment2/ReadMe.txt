CSE556 Introduction to NLP Assignment 2

1.	Assumptions:
		Paragraphs:
			I assume that there is a blank line between any two paragraphs. So, I look for '\n\n'.
		
		Sentences:
			I assume that a sentence ends in either full stop (.), question mark (?), exclamation mark (!) or semi-colon (;). And the first letter of the next word will be a capital letter. Also, to avoid including abbrevations (like B.P.M.), I check if first letter of the current word is a capital letter. I assume that abbrevations start with a capital letter.
		
		Words:
			I simply assume that each word is separated by a space. There is no special character with spaces on both sides. I use "[\w\-\.\']+" which allows me to find all words with hyphens (-), full stops (.) or apostrophe ('). e.g.: 39-year-old, B.P.M., don't, etc.

	Counts ("Development Set.txt"):
		No. of paragraphs: 8
		No. of sentences: 27
		No. of words: 647

2.	First Word of Each sentence:
		I create a dictionary of first words for every sentence. The dictionary stores the count of the given first word in all the sentences. I use this dictionary to find the count of the input word. The dictionary is stored as fwdic.json.

3.	Last Word of Each sentence:
		I create a dictionary of last words for every sentence. The dictionary stores the count of the given last word in all the sentences. I use this dictionary to find the count of the input word. The dictionary is stored as lwdic.json.

4.	Count of Given Word:
		I create a dictionary of all the words. The dictionary stores the frequency of occurrence of every word in the corpus. I use this dictionary to find the count of the input word. The dictionary is stored as worddic.json.

Sanidhya Singal 2015085