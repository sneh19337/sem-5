
# coding: utf-8

# In[1]:

# Imports

import nltk
import pickle
from nltk import Nonterminal, nonterminals, Production, CFG
from nltk.tree import *
from nltk.draw import tree


# In[2]:

f = open('cnf_grammar.pkl', 'rb') #load CNF Grammar
cnf_ = pickle.load(f)
f.close()


# In[3]:

# print(cnf_)
# rules = list(cnf_.productions())


# In[4]:

sentences = nltk.data.load('grammars/large_grammars/atis_sentences.txt')
testsentences = nltk.parse.util.extract_test_sentences(sentences)

allsentences = []

for t in testsentences:
    onesentence = t[0]
    allsentences.append(onesentence)

allsentences.sort(key=len)


# In[5]:

parser = nltk.parse.BottomUpChartParser(cnf_)

num_parse_trees = {}
for sentence in allsentences[:5]:
    count = 0
    line = ' '.join(sentence)
    
    try:
        trees = parser.parse(sentence)
    except:
        print(line + "\t" + str(count))
        continue
    
    for tree in trees:
        count += 1
            
    print(line + "\t" + str(count))
    num_parse_trees[line] = count

f = open('num_parse_trees.pkl', 'wb')
pickle.dump(num_parse_trees, f)
f.close()


# In[7]:

testsent = allsentences[4]

trees = parser.parse(testsent)
for tree in trees:
    tree.draw()


# In[ ]:



