CSE556 Introduction to NLP Assignment 5 (CYK Parser)

For converting the given Context Free Grammar to Chomsky Normal Form, run "cfg2cnf.py". It reads "atis.cfg" grammar from nltk and stores the CNF grammar as "cnf_grammar.pkl". Both CFG and CNL are also stored as "atis_cfg.pkl" and "atis_cnf.pkl" respectively.

For running the parser on CNF grammar, run "cykParser.py". It takes "cnf_grammar.pkl" and test sentences from nltk and parses them.
Following are the outputs:
1. The ATIS sentences and the corresponding number of parse trees are stored in "output.txt" in the specified output format.
2. We look at a particular sentence: "indianapolis to seattle .". It has 7 parse trees which are stored as Tree1.PNG, Tree2.PNG, ..., Tree7.PNG.

Sanidhya Singal 2015085