
# coding: utf-8

# In[1]:

# Imports

import nltk
from nltk import Nonterminal, nonterminals, Production, CFG
import pickle


# In[2]:

# Load ATIS CFG

cfg_ = nltk.data.load("grammars/large_grammars/atis.cfg")
# print(cfg_)
allrules = list(cfg_.productions()) #List of all rules

def left_(r):
    return r.lhs()

allrules.sort(key=left_) #Sort rules acc to left hand side


# In[3]:

f = open('atis_cfg.pkl', 'wb')
pickle.dump(allrules, f)
f.close()


# In[4]:

# Stats

print(cfg_.is_nonlexical())
print(cfg_.is_lexical())
print(cfg_.is_nonempty())
for rule in allrules:
    for i in rule.rhs():
        if (nltk.grammar.is_nonterminal(i) == False and len(rule.rhs()) > 1):
            print(rule)
print(cfg_.max_len(), cfg_.min_len())

'''So, grammar is of the form A->B0 B1 ... Bn, A->"s" where 0<=n<=10. There are no rules of the form A->B"c".'''


# In[5]:

# print(allrules[0].lhs())
# a = cfg_.leftcorner_parents(Nonterminal('ADJ_AP'))
# b = cfg_.leftcorners(Nonterminal('ADJ_AP'))
# print(a)
# print(b)
# c = cfg_.leftcorners(Nonterminal('only'))
# print(c)
# d = cfg_.productions(Nonterminal('ADJ_AP'))
# print(d)

f = open('atis_cfg.pkl', 'rb')
allrules = pickle.load(f)
f.close()


# In[6]:

# Remove A->"s" and A->BC rules

newrules = []

for rule in allrules[:]:
    if (rule.is_lexical() == True):
        newrules.append(rule)
        allrules.remove(rule)
    elif (len(rule) == 2):
        newrules.append(rule)
        allrules.remove(rule)
        
# Remove A->A rules
for rule in allrules[:]:
    if (len(rule) == 1 and rule.lhs() == rule.rhs()[0]):
        allrules.remove(rule)


# In[7]:

print(len(newrules))
print(len(allrules))
# print(allrules)


# In[8]:

# Handle single rules A->B

def handle_singles(rule):
    p = cfg_.productions(rule.rhs()[0])
#                 if (rule.lhs() == Nonterminal('SIGMA')):
#                     print(p)
    for i in p:
        if (len(i) == 1):
            if (nltk.grammar.is_nonterminal(i.rhs()[0]) == False):
                newrules.append(Production(rule.lhs(), i.rhs()))
            else:
                handle_singles(Production(rule.lhs(), i.rhs()))
        else:
            prod = Production(rule.lhs(), i.rhs())
            if prod not in allrules:
                allrules.append(prod)

for rule in allrules[:]:
    if (len(rule) == 1):
        handle_singles(rule)
        allrules.remove(rule)


# In[9]:

print(len(newrules))
print(len(allrules))


# In[10]:

# Handle long rules A->B0 B1 ... Bn

def checkinrhs(r1, r2):
    for rule in newrules[:]:
        if (rule.rhs()[0] == r1 and rule.rhs()[1] == r2):
            return rule.lhs()
    return None
        
def handle_long(rule, idx):
    if (len(rule) > 2):
        rh = list(rule.rhs())
        lh = checkinrhs(rh[-2], rh[-1])
        if (lh == None):
            z = Nonterminal("Z" + str(idx))
            newrules.append(Production(z, (rh[-2], rh[-1])))
            rh = rh[:-2]
            rh.append(z)
            newrule = Production(rule.lhs(), rh)
        
        else:
            rh = rh[:-2]
            rh.append(lh)
            newrule = Production(rule.lhs(), rh)
#         newrule = Production(rh[:-2])
        return (handle_long(newrule, idx+1))
        
    if (len(rule) == 2):
        newrules.append(rule)
        return (idx-1)

indd = 1
for rule in allrules[:]:
    if (len(rule) > 2):
        indd = handle_long(rule, indd)
        allrules.remove(rule)
        indd += 1
    
    if (len(rule) == 2):
        newrules.append(rule)
        allrules.remove(rule)


# In[11]:

print(len(newrules))
print(len(allrules))
# print(newrules)
print(allrules)


# In[24]:

# Create CNF Grammar

cnf_ = CFG(start=Nonterminal('SIGMA'), productions=newrules)


# In[25]:

f = open('cnf_grammar.pkl', 'wb')
pickle.dump(cnf_, f)
f.close()


# In[26]:

#  Check CNF

print(cnf_.is_chomsky_normal_form())


# In[27]:

# CNF Rules

fin = list(cnf_.productions())
fin.sort(key=left_)


# In[28]:

f = open('atis_cnf.pkl', 'wb')
pickle.dump(fin, f)
f.close()


# In[29]:

f = open('atis_cnf.pkl', 'rb')
a = pickle.load(f)
f.close()

for i in a:
    print(i)

