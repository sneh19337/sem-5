
# coding: utf-8

# In[1]:

#Import packages

import os
import nltk
import json
import pickle
import random
import copy
from math import log10, ceil
from nltk.tokenize import sent_tokenize
from nltk.tokenize import RegexpTokenizer

cwd = os.getcwd() #Current Working Directory
tokenizer = RegexpTokenizer(r'\w+' + r'|' + r'<b>' + r'|' + r'<e>') #Tokenizer


# In[2]:

fp = open(os.path.join(cwd, r"unig_comp.graphics.pkl"), 'rb')
unig_gr = pickle.load(fp)
fp.close()

fp = open(os.path.join(cwd, r"unig_rec.motorcycles.pkl"), 'rb')
unig_mot = pickle.load(fp)
fp.close()


# In[3]:

thresh = 1

unk_gr = []
for key, val in unig_gr.items():
    if val <= thresh:
        unk_gr.append(key)

num = round(0.01*len(unig_gr))
unk_gr = random.sample(unk_gr, num)

unk_mot = []
for key, val in unig_mot.items():
    if val <= thresh:
        unk_mot.append(key)


num = round(0.01*len(unig_mot))
unk_mot = random.sample(unk_mot, num)


# In[4]:

# len(unk_gr)


# In[5]:

# len(unk_mot)


# In[6]:

cwd = os.getcwd() #Current Working Directory
folder_name = r"20_newsgroups"


# In[7]:

for class_name in [r"comp.graphics", r"rec.motorcycles"]:
    folder_path = os.path.join(cwd, os.path.join(folder_name, class_name))

    unig = {} #Unigram Dictionary
    big = {} #Bigram Dictionary

    for root, _, files in os.walk(folder_path):
        for file in files:

            file_path = os.path.join(folder_path, file)

            lines = ""

            f = open(file_path, 'r')

            lines = f.read()

            sentences = sent_tokenize(lines) #Sentence tokenize
            sentences = ["<b> " + sentence + " <e>" for sentence in sentences] #Add begin and end tags to each sentence

            words = []

            for sentence in sentences:
                words += tokenizer.tokenize(sentence)  #tokenize

            words = [word.strip('_ ').lower() for word in words] #lowercase
            words = [word for word in words if len(word)>0]

            if (class_name == "comp.graphics"):
                for j in range(len(words)):
                    if (words[j] in unk_gr):
                        words[j] = "<UNK>"

            elif (class_name == "rec.motorcycles"):
                for j in range(len(words)):
                    if (words[j] in unk_mot):
                        words[j] = "<UNK>"

            for word in words: #Unigram
                if word not in unig:
                    unig[word] = 0
                unig[word] += 1

            for i in range(len(words)-1): #Bigram
                if words[i] not in big:
                    big[words[i]] = {}
                if words[i+1] not in big[words[i]]:
                    big[words[i]][words[i+1]] = 0
                big[words[i]][words[i+1]] += 1

#         print(unig["<UNK>"])
#         print(big["<UNK>"])

    if (class_name == "comp.graphics"):
        unig_gr = copy.deepcopy(unig)
        big_gr = copy.deepcopy(big)
    elif (class_name == "rec.motorcycles"):
        unig_mot = copy.deepcopy(unig)
        big_mot = copy.deepcopy(big)

    #Store dictionaries as pickle files
    fp = open(os.path.join(cwd, r"unig_UNK" + class_name + ".pkl"), 'wb')
    pickle.dump(unig, fp)
    fp.close()

    fp = open(os.path.join(cwd, r"big_UNK" + class_name + ".pkl"), 'wb')
    pickle.dump(big, fp)
    fp.close()

    #Store dictionaries as json files
#     fp = open(os.path.join(cwd, r"unig_UNK" + class_name + ".json"), 'w+')
#     json.dump(unig, fp, sort_keys=True)
#     fp.close()

#     fp = open(os.path.join(cwd, r"big_UNK" + class_name + ".json"), 'w+')
#     json.dump(big, fp, sort_keys=True)
#     fp.close()


# In[ ]:



