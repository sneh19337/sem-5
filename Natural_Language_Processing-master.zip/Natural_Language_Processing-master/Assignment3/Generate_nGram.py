
# coding: utf-8

# In[1]:

#Import packages

import os
import nltk
import json
import pickle
import random
import copy
from math import log10, ceil
from nltk.tokenize import sent_tokenize
from nltk.tokenize import RegexpTokenizer


# In[2]:

cwd = os.getcwd() #Current Working Directory
folder_name = r"20_newsgroups"

print('''Select Class:
1. comp.graphics
2. rec.motorcycles
Enter choice:''')
c = int(input())

if (c == 1):
    class_name = r"comp.graphics" #comp.graphics or rec.motorcycles
else:
    class_name = r"rec.motorcycles"
folder_path = os.path.join(cwd, os.path.join(folder_name, class_name))


# In[3]:

thresh = 70 #Avg sentence length/2


# In[4]:

print('''Sentence Generation:
1. Unigram
2. Bigram
3. Trigram
Enter choice: ''')
x = int(input())


# In[5]:

#Unigram Generation
if (x == 1):

    fp = open(os.path.join(cwd, r"unig_" + class_name + ".pkl"), 'rb')
    unig = pickle.load(fp)
    fp.close()

    sorted_unig = sorted(unig.items(), key=lambda x: x[1], reverse=True)

    print("<b>", end=" ")
    for i in range(2, thresh):
        print(sorted_unig[i][0], end=" ")
    print("<e>")


# In[6]:

#Bigram Generation
if (x == 2 or x == 3):
    fp = open(os.path.join(cwd, r"big_" + class_name + ".pkl"), 'rb')
    big = pickle.load(fp)
    fp.close()

    def find_big(word):
        d = big[word]
        sorted_d = sorted(d.items(), key=lambda x: x[1], reverse=True)
        possible_words = sorted_d[:ceil(len(sorted_d)/thresh)]
    #     for i in range(len(possible_words)):
    #         if (possible_words[i][0] == '<e>'):
    #             possible_words.pop(i)
    #             break
    #     if (len(possible_words) == 0):
    #         return sorted_d[0][0]
        return (random.choice(possible_words)[0])

    # res = find_big('<b>')
    # print("<b>", end=" ")
    # for i in range(2, thresh):
    #     if (res != "<b>" and res != "<e>"):
    #         print(res, end=" ")
    #     res = find_big(res)
    # print("<e>")

    if (x == 2):
        print("<b>", end=" ")
        res = find_big('<b>')
        for i in range(2, thresh):
            if (res == "<e>"):
                break
            print(res, end=" ")
            res = find_big(res)
        print("<e>")
        
    #Trigram Generation
    if (x == 3):
        fp = open(os.path.join(cwd, r"trig_" + class_name + ".pkl"), 'rb')
        trig = pickle.load(fp)
        fp.close()

        def find_trig(word):
            res = find_big(word)
            if (res == "<e>"):
                return res
            print(res, end=" ")
            d = trig[word][res]
            sorted_d = sorted(d.items(), key=lambda x: x[1], reverse=True)
            return sorted_d[0][0]

        print("<b>", end=" ")
        res = find_trig('<b>')
        for i in range(3, thresh):
            if (res == "<e>"):
                break
            print(res, end=" ")
            res = find_trig(res)
        print('<e>')


# In[ ]:



