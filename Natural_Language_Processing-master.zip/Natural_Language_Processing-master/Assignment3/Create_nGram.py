
# coding: utf-8

# In[1]:

#Import packages

import os
import nltk
import json
import pickle
import random
import copy
from math import log10, ceil
from nltk.tokenize import sent_tokenize
from nltk.tokenize import RegexpTokenizer

tokenizer = RegexpTokenizer(r'\w+' + r'|' + r'<b>' + r'|' + r'<e>') #Tokenizer


# In[2]:

cwd = os.getcwd() #Current Working Directory
folder_name = r"20_newsgroups"
for class_name in [r"comp.graphics" , r"rec.motorcycles"]:
    folder_path = os.path.join(cwd, os.path.join(folder_name, class_name))

    unig = {} #Unigram Dictionary
    big = {} #Bigram Dictionary
    trig = {} #Trigram Dictionary

    sent_len = 0
    num_sent = 0

    for root, _, files in os.walk(folder_path):
        for file in files:

            file_path = os.path.join(folder_path, file)

            lines = ""

            f = open(file_path, 'r')

            lines = f.read()

            sentences = sent_tokenize(lines) #Sentence tokenize
            num_sent += len(sentences)
            for sentence in sentences:
                sent_len += len(sentence)
            sentences = ["<b> " + sentence + " <e>" for sentence in sentences] #Add begin and end tags to each sentence

            words = []

            for sentence in sentences:
                words += tokenizer.tokenize(sentence)  #tokenize

            words = [word.strip('_ ').lower() for word in words] #lowercase
            words = [word for word in words if len(word)>0]

            for word in words: #Unigram
                if word not in unig:
                    unig[word] = 0
                unig[word] += 1

            for i in range(len(words)-1): #Bigram
                if words[i] not in big:
                    big[words[i]] = {}
                if words[i+1] not in big[words[i]]:
                    big[words[i]][words[i+1]] = 0
                big[words[i]][words[i+1]] += 1

            for i in range(len(words)-2): #Trigram
                if words[i] not in trig:
                    trig[words[i]] = {}
                if words[i+1] not in trig[words[i]]:
                    trig[words[i]][words[i+1]] = {}
                if words[i+2] not in trig[words[i]][words[i+1]]:
                    trig[words[i]][words[i+1]][words[i+2]] = 0
                trig[words[i]][words[i+1]][words[i+2]] += 1

    bigf = copy.deepcopy(big)
    for word in big:
        d = big[word]
        for key, val in d.items():
            d[key] = log10(val/unig[word])
        big[word] = d
    
    for wordi in trig:
        for wordj in trig[wordi]:
            d = trig[wordi][wordj]
            for key, val in d.items():
                d[key] = log10(val/unig[wordi])
            trig[wordi][wordj] = d
    
    #Store dictionaries as pickle files
    fp = open(os.path.join(cwd, r"unig_" + class_name + ".pkl"), 'wb')
    pickle.dump(unig, fp)
    fp.close()

    fp = open(os.path.join(cwd, r"bigf_" + class_name + ".pkl"), 'wb')
    pickle.dump(bigf, fp)
    fp.close()
    
    fp = open(os.path.join(cwd, r"big_" + class_name + ".pkl"), 'wb')
    pickle.dump(big, fp)
    fp.close()

    fp = open(os.path.join(cwd, r"trig_" + class_name + ".pkl"), 'wb')
    pickle.dump(trig, fp)
    fp.close()

    #Store dictionaries as json files
    # fp = open(os.path.join(cwd, r"unig_" + class_name + ".json"), 'w+')
    # json.dump(unig, fp, sort_keys=True)
    # fp.close()

    # fp = open(os.path.join(cwd, r"bigf_" + class_name + ".json"), 'w+')
    # json.dump(bigf, fp, sort_keys=True)
    # fp.close()
    
    # fp = open(os.path.join(cwd, r"big_" + class_name + ".json"), 'w+')
    # json.dump(big, fp, sort_keys=True)
    # fp.close()

    # fp = open(os.path.join(cwd, r"trig_" + class_name + ".json"), 'w+')
    # json.dump(trig, fp, sort_keys=True)
    # fp.close()


# In[4]:

# avg_sent_len = sent_len//num_sent + 2
# print(avg_sent_len)


# In[6]:

# len(unig)

