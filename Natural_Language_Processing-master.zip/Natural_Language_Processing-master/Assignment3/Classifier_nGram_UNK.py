
# coding: utf-8

# In[1]:

#Import packages

import os
import nltk
import json
import pickle
import random
import copy
from math import log10, ceil
from nltk.tokenize import sent_tokenize
from nltk.tokenize import RegexpTokenizer

cwd = os.getcwd() #Current Working Directory
tokenizer = RegexpTokenizer(r'\w+' + r'|' + r'<b>' + r'|' + r'<e>') #Tokenizer


# In[2]:

fp = open(os.path.join(cwd, r"unig_UNKcomp.graphics.pkl"), 'rb')
unig_gr = pickle.load(fp)
fp.close()

fp = open(os.path.join(cwd, r"big_UNKcomp.graphics.pkl"), 'rb')
big_gr = pickle.load(fp)
fp.close()

fp = open(os.path.join(cwd, r"unig_UNKrec.motorcycles.pkl"), 'rb')
unig_mot = pickle.load(fp)
fp.close()

fp = open(os.path.join(cwd, r"big_UNKrec.motorcycles.pkl"), 'rb')
big_mot = pickle.load(fp)
fp.close()


# In[7]:

print('''Classification:
Enter a sentence:''')
sent = input()


# In[8]:

words = []
words += tokenizer.tokenize(sent)
words = [word.strip('_ ').lower() for word in words] #lowercase
words = [word for word in words if len(word)>0]

for i in range(len(words)):
    if (words[i] not in unig_gr or words[i] not in unig_mot):
        words[i] = "<UNK>"


# In[9]:

# print(words)


# In[10]:

sum1 = 0
sum2 = 0

for i in range(len(words)-1):
    if words[i] in unig_gr:
        if words[i+1] in big_gr[words[i]]:
            sum1 += log10((big_gr[words[i]][words[i+1]] + 1)/(unig_gr[words[i]] + len(unig_gr)))
        else:
            sum1 += log10(1/(unig_gr[words[i]] + len(unig_gr)))
    else:
        sum1 += -float('Inf')

for i in range(len(words)-1):
    if words[i] in unig_mot:
        if words[i+1] in big_mot[words[i]]:
            sum2 += log10((big_mot[words[i]][words[i+1]] + 1)/(unig_mot[words[i]] + len(unig_mot)))
        else:
            sum2 += log10(1/(unig_mot[words[i]] + len(unig_mot)))
    else:
        sum2 += -float('Inf')

print(sum1)
print(sum2)

if (sum1 > sum2):
    print("com.graphics")
elif (sum2 > sum1):
    print("rec.motorcycles")

