CSE556 Introduction to NLP Assignment 2

Q1	
	Corpus:
		1000 files in comp.graphics folder as a single corpus

	Preprocessing:
		- Used NLTK for sentence and word tokenization
		- Converted all words to lowercase (normalization)
		- Stripped any extra spaces and underscores
		- Added 2 tags - <b>, <e> marking the beginning and end of each sentence.

	Create Unigram:
		- Created dictionary named 'unig' for storing unigram counts.
		- Gives count for each word in the corpus
		- Stored as 'unig_comp.graphics.pkl'
		- Refer to 'Create_nGram.py'

	Generate Unigram:
		- Observed that the average length of a sentence is 140. So, generated unigram of half the length.
		- Took top 70 most frequently occuring words.
		- Refer to 'Generate_nGram.py'

		Output: 
			<b> the edu to a and of i is for in graphics it cmu comp cs you from that on com news this srv or be with net s image cantaloupe are can have 1 if as lines message subject date newsgroups path id not organization t but at apr an gmt jpeg by will there 1993 2 state file any ohio x university some about re images 0 <e>

	Create Bigram:
		- Created dictionaries named 'big' and 'bigf' for storing bigram probabilities and counts respectively.
		- Every two adjacent words appearing in the corpus are stored as bigrams.
		- Every possible bigram not stored. So, dense representation.
		- Bigram counts are normalized by unigram counts and stored as probabilities.
		- Stored as 'big_comp.graphics.pkl' and 'bigf_comp.graphics.pkl'
		- Refer to 'Create_nGram.py'

	Generate Bigram:
		- Every sentence starts with <b> and ends with <e>. So, starting with <b>, find all the possible words that come after <b>. Sort them in descending order. Randomly choose one word from the top k possible words. Now find all possible words that come after the chosen word. Sort them in descending order and randomly choose one from the top k. Continue the process till the choosen word is <e> or the length of sentence is 70.
		- Refer to 'Generate_nGram.py'

		Outputs:
			1. <b> we have to create the following is also a simple and then i have the most of an ftp site for image <e>
			2. <b> also a bit image quality setting to be a set of image manipulation and image quality setting to get the subject need to get the file format <e>

	Create Trigram:
		- Created dictionary named 'trig' for storing trigram probabilities.
		- Every three adjacent words appearing in the corpus are stored as trigrams.
		- Every possible trigram not stored. So, dense representation.
		- Trigram counts are normalized by unigram counts and stored as probabilities.
		- Stored as 'trig_comp.graphics.pkl'
		- Refer to 'Create_nGram.py'

	Generate Trigram:
		- Same as in Bigram.
		- Refer to 'Generate_nGram.py'

		Outputs:
			1. <b> there are some rules of thumb for converting gifs <e>
			2. <b> what i have a new version of the next in your own a genlock and i am looking for a program that the image <e>

Q2
	Corpus:
		1000 files in rec.motorcycles folder as a single corpus

	All steps similar to Q1

	Outputs:
		Unigram:
			<b> the edu a i to com and of in it you cmu is that news cs on for from motorcycles srv my s rec net t re with apr message cantaloupe subject id was organization date this path lines newsgroups ca gmt have writes bike state article references be not or but at are as if dod ohio 1993 can me your do howland sun sender so what <e>

		Bigram:
			1. <b> it and you are you ll be in the last night with my first bike disclaimer now why would be the fact remains 71 bmw moa members read this is not necessarily those of the best of wild corn dogs <e>
			2. <b> he was drinking last night with my new to know what i d fxwg wide glide jubilee s the way to me and then i m a problem <e>

		Trigram:
			1. <b> you can t wear out davet interceptor cds tek com date tue 20 apr 1993 16 gmt lines 18 in that they re built like rocks 65 r50 2 velorex 57 nsu max to be a picture of my bike and i d <e>
			2. <b> message id 1993apr5 195058 1465 cbfsb cb att com charles parr writes the other message id 1993apr5 195058 1465 cbfsb cb att com charles parr writes i am looking for the front of traffic jerks message id 1993apr15 222224 1 1 pl8 references 1993apr20 195116 123380 locus com organization nec com chris behanna dod 114 1983 h d <e>
 
Q3.1
	- Built a simple classifier that finds score of a given sentence based on the bigram scores (log10 of probability) for each class. The class with the higher score is chosen. 
	- If a word in the sentence is not present in the corpus, the output is -inf.
	- Done add 1 smoothing. Refer to 'Classifier_nGram_Smoothing.py'.

Q3.2	
	- <UNK>: For every word in the corpus that had a count of 1 or less, I replaced 1% of them with <UNK> tag. Created the unigram and bigram dictionaries again. Refer to 'Create_nGram_UNK.py' for the same. 
	- Built a simple classifier that finds score of a given sentence based on the bigram scores (log10 of probability) for each class. The class with the higher score is chosen.
	- If a word in the sentence is not present in the corpus, it is replaced by <UNK> tag.
	- Done add 1 smoothing. Refer to 'Classifier_nGram_UNK.py'.

Sanidhya Singal 2015085