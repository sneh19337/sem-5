CSE556 Introduction to NLP Assignment 4 (HMM)

Train HMM
	- Read the training dataset
	- Stored words, tags, word-tag pairs and previousTag-currentTag pairs as lists
	
	Unknown Words:
		There are approx. 150000 words in the training set. I decided to replace 0.5% of the least frequent words by 'UNK', i.e., approx. 750 words (~150 unique words). All the above lists were updated accordingly. 

	WordMappingDict and TagMappingDict map words and tags to unique integers (useful for indexing).

	MatrixA:
		States transition matrix where a(i,j) gives the probability of going from state i to state j. In our case, states are tags and as we are dealing with HMMs, we consider only bigram probabilities. In order to avoid 0s, 'Laplace Add 1 smoothing' has been done.

	MatrixB:
		Words observation matrix where b(ot, s) gives the probability of observation o at time t when the state is s. In our case, states are tags and observations are corresponding words. In HMM, b depends only on current state and current observation. Again 'Laplace Add 1 smoothing' has been done to avoid 0s.
	
	In both matrices, I took log of the values in order to avoid floating point underflow during multiplication.

Decode HMM
	- In this step, we read a test file which contains only words. If the word was not seen in the training set, it wass replaced by 'UNK'.
	- We implemented the Viterbi algorithm. It provides a set of back pointers for each word in the test set. Traversing the back pointers in the reverse order leads us to the POS tags of the words in the test set.
	- Output is stored in 'Output.txt'.
	- Accuracy on running the model with training set is 89.6%.

Sanidhya Singal 201085