
# coding: utf-8

# In[1]:

#Imports
import os
import pickle
import numpy as np


# In[2]:

cwd = os.getcwd()


# In[3]:

f = open(os.path.join(cwd, r"Training set_HMM.txt"), 'r')

w_t_pairs = [] #Word-Tag pairs
pt_t_pairs = [] #PreviousTag-CurrentTag pairs
words = [] #List of all the words
tags = [] #List of all the tags
prev_tag = 'START' #Initially previous tag is START

for line in f:
    if line != '\n':
        word, tag = line.split('\t')

        word = word.strip() 
        tag = tag.strip() #Strip off \n
        
        words.append(word)
        tags.append(tag)
        
        w_t_pairs.append((word, tag))
        pt_t_pairs.append((prev_tag, tag))
        
        prev_tag = tag
    
    else:
        prev_tag = 'START'
    
f.close()


# In[4]:

#Handle unknown words by replacing 0.5% of words by UNK.
#There are 150000 words, 0.5% of which is 750. So, we replace 750 least frequent words by UNK.

word_freq = {} #Dict for frequency of unique words
uniq_words = list(set(words)) #List of unique words

for word in uniq_words:
    word_freq[word] = 0

for word in words:
    word_freq[word] += 1

freq_values = sorted(word_freq.items(), key=lambda kv: kv[1])

for i in range(300): #Remove 750 least freq words
    words.remove(freq_values[i][0])
    words.append('UNK') #Add UNK in their place
    
    for j in range(len(w_t_pairs)): #Update Word-Tag pairs
        if (w_t_pairs[j][0] == freq_values[i][0]):
            w_t_pairs[j] = ('UNK', w_t_pairs[j][1])


# In[5]:

# uniq_words, w_freq = np.unique(np.asarray(words), return_counts=True)

# print(w_freq)

# word_freq = {}
# for i in range(len(uniq_words)):
#     word_freq[uniq_words[i]] = w_freq[i]
# 
# w_freq = np.sort(w_freq)
# c_freq = [w_freq[0]]
# for i in range(1, len(w_freq)):
#     c_freq.append(w_freq[i]+c_freq[i-1])
#     if (c_freq[i] > 750):
#         print(i)
#         break
    
# print(c_freq)

uniq_words = list(set(words)) #List of unique words

uniq_tags = list(set(tags)) #List of unique tags with START and END added to them
uniq_tags.append('START')
uniq_tags.append('END')


# In[6]:

word_dic = {} #Word to integer mapping
k = 0

for word in uniq_words:
    if word not in word_dic:
        word_dic[word] = k
        k += 1


# In[7]:

f = open(os.path.join(cwd, r'WordMappingDic.pickle'), 'wb')
pickle.dump(word_dic, f)
f.close()


# In[8]:

tag_dic = {} #Tag to integer mapping
k = 0

for tag in uniq_tags:
    if tag not in tag_dic:
        tag_dic[tag] = k
        k += 1


# In[9]:

f = open(os.path.join(cwd, r'TagMappingDic.pickle'), 'wb')
pickle.dump(tag_dic, f)
f.close()


# In[10]:

# print(tag_dic)
# print(len(word_dic))
# print(len(tag_dic))


# In[11]:

a = np.zeros((len(tag_dic), len(tag_dic)))  #States Transition Matrix a(i,j) for going from tag i to tag j
b = np.zeros((len(word_dic), len(tag_dic))) #Observation Matrix b(i,j) for observing word i at state j (word i has tag j)

# print(a.shape, b.shape)


# In[12]:

for i,j in pt_t_pairs:
    a[tag_dic[i]][tag_dic[j]] += 1
    
for i,j in w_t_pairs:
    b[word_dic[i]][tag_dic[j]] += 1


# In[13]:

tag_freq = {} #Tag Freq

for tag in tag_dic:
    tag_freq[tag_dic[tag]] = 0

for tag in tags:
    tag_freq[tag_dic[tag]] += 1
    
# print(tag_freq)


# In[14]:

for i in range(a.shape[0]):
    for j in range(a.shape[1]):
        a[i][j] = np.log2((a[i][j]+1)/(tag_freq[i]+len(tags))) #Add 1 smoothing and log
        
for i in range(b.shape[0]):
    for j in range(b.shape[1]):
        b[i][j] = np.log2((b[i][j]+1)/(tag_freq[j]+len(words))) #Add 1 smoothing and log


# In[15]:

f = open(os.path.join(cwd, r'MatrixA.pickle'), 'wb')
pickle.dump(a, f)
f.close()

f = open(os.path.join(cwd, r'MatrixB.pickle'), 'wb')
pickle.dump(b, f)
f.close()


# In[16]:

# print(len(words))
# print(len(uniq_words))

