import spacy

nlp = spacy.load('en_core_web_md')  

print("Enter 2 Words (separated by space): ")
words = input()

tokens = nlp(words)

print("Token1\t\tToken2\t\tSimilarity")
print("-"*60)
for token1 in tokens:
	for token2 in tokens:
		print(str(token1.text) + "\t\t" + str(token2.text) + "\t\t" + str(token1.similarity(token2)))