from gensim.models import Word2Vec
from gensim.models import KeyedVectors

filename = 'GoogleNews-vectors-negative300.bin'
model = KeyedVectors.load_word2vec_format(filename, binary=True) #Load Model

print("""If Delhi is the capital of India then what is the capital of China?""")
print(model.wv.most_similar(positive=['China', 'Delhi'], negative=['India'], topn=1)) # China - India + Delhi = Beijing

print()
print("""If ISRO is related to India then what is related to USA""")
print(model.wv.most_similar(positive=['USA', 'ISRO'], negative=['India'], topn=1)) # USA - India + ISRO = NASA