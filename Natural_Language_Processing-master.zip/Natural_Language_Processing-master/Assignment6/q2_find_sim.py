
# coding: utf-8

# In[21]:

import gensim
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
import os
import pickle


# In[22]:

cwd = os.getcwd()
folders_path = os.path.join(cwd, r"20_newsgroups")


# In[60]:

model = Doc2Vec.load('doc2vec.model')


# In[24]:

f = open(os.path.join(cwd, r'all_data.pkl'), 'rb')
all_data = pickle.load(f)
f.close()

f = open(os.path.join(cwd, r'docLabels.pkl'), 'rb')
docLabels = pickle.load(f)
f.close()


# In[61]:

print("""comp.graphics's Doc1's similarity with one document each from other folders: """)

doc1 = os.path.join(cwd, r'20_newsgroups\comp.graphics\37261')
doc1tag = all_data[docLabels.index(doc1)]

count = 0
avg_sim = 0
for root, _, files in os.walk(folders_path):
    for file in files:
        doc2 = os.path.join(root, file)
        if 'comp.graphics' in doc2.split('\\')[-2:]: #Not comparing with itself
            break
        doc2tag = all_data[docLabels.index(doc2)]
        count += 1
        
        sim = model.n_similarity(doc1tag, doc2tag)
        avg_sim += sim
        
        print("Similarity of " + str(doc1.split('\\')[-2:]) + " and " + str(doc2.split('\\')[-2:]) + ":   " + str(sim))
        break

print(avg_sim/count)


# In[62]:

print("""comp.graphics's Doc1's similarity with 19 other documents: """)

graphics_folder_path = os.path.join(cwd, r'20_newsgroups\comp.graphics')
doc1 = os.path.join(cwd, r'20_newsgroups\comp.graphics\37261')
doc1tag = all_data[docLabels.index(doc1)]

count = 0
avg_sim = 0
for root, _, files in os.walk(graphics_folder_path):
    for file in files:
        doc2 = os.path.join(root, file)
        if '37261' in doc2.split('\\')[-2:]: #Not comparing with itself
            continue
        doc2tag = all_data[docLabels.index(doc2)]
        count += 1
       
        if (count == 20):
            break
        sim = model.n_similarity(doc1tag, doc2tag)
        avg_sim += sim
        
        print("Similarity of " + str(doc1.split('\\')[-1:]) + " and " + str(doc2.split('\\')[-1:]) + ":   " + str(sim))

print(avg_sim/(count-1))

