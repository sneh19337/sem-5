CSE556 Introduction to NLP Assignment 6 (NLP Tools and Techniques) 

Q1
Loaded the "GoogleNews-vectors-negative300.bin" model using gensim.
1. If Delhi is the capital of India then what is the capital of China? --> China - India + Delhi --> Beijing
2. If ISRO is related to India then what is related to USA --> USA - India + ISRO --> STScI

Q2
Used gensim's Doc2Vec model. I trained the model on the complete 20_newsgroups corpus in 'q2_create_model.py'. The model is saved as 'doc2vec.model' along with the documents and their labels as 'all_data.pkl' and 'docLabels.pkl' respectively. The data is cleaned and preprocessed initially using NLTK's stopwords removal and tokenizer.

These are then used to compute the document vectors and then, the similarity values. We do so in 'q2_find_sim.py'.
The similarity values are calculated using model.n_similarity(doc1, doc2).
Following are the avg values:
Between doc1 of comp.graphics and docs of other 19 folders: 94.6%
Between doc1 and 19 other docs of comp.graphics folder: 95.4%

Q3
a.	Used 'en_core_web_sm' model from spacy.
	Found Lemma using token.lemma_
	Found POS and tag using token.pos_, token.tag_.

b.	Used 'en_core_web_sm' model from spacy.
	Found Named Entities using doc.ents.
	Found their labels using ent.label_.

c.	Used 'en_core_web_md' model from spacy.
	Found similarity using token1.similarity(token2).

Sanidhya Singal 2015085