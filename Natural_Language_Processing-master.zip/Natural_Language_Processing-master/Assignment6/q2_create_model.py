
# coding: utf-8

# In[9]:

import gensim
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
import os
from nltk import RegexpTokenizer
from nltk.corpus import stopwords
import pickle


# In[10]:

cwd = os.getcwd()
folders_path = os.path.join(cwd, r"20_newsgroups")
folders = os.listdir(folders_path) #List of folders

docLabels = []
data = []


# In[11]:

for root, _, files in os.walk(folders_path):
    for file in files:
        file_path = os.path.join(root, file)
        f = open(file_path, 'r')
        data.append(f.read())
        f.close()
        docLabels.append(file_path)


# In[12]:

tokenizer = RegexpTokenizer(r'\w+')
stopword_set = set(stopwords.words('english'))

def preprocessing(data):
    new_data = []
    for d in data:
        new_str = d.lower()
        dlist = tokenizer.tokenize(new_str)
        dlist = list(set(dlist).difference(stopword_set))
        new_data.append(dlist)
    return new_data

all_data = preprocessing(data)


# In[13]:

documents = [TaggedDocument(all_data[i], [docLabels[i]]) for i in range(len(all_data))]


# In[14]:

model = Doc2Vec(documents, vector_size=150, alpha=0.25, min_aplha=0.001, window=5, epochs=10, min_count=0, workers=4)
# model = Doc2Vec(documents, vector_size=100)


# In[15]:

model.save('doc2vec.model')


# In[16]:

f = open(os.path.join(cwd, r'all_data.pkl'), 'wb')
pickle.dump(all_data, f)
f.close()

f = open(os.path.join(cwd, r'docLabels.pkl'), 'wb')
pickle.dump(docLabels, f)
f.close()

