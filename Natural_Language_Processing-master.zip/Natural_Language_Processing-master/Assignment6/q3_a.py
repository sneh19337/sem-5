import spacy

print("""Choose among the following: 
    1. Document
    2. Sentence
    3. Sample Sentence""")

inp = int(input())

if (inp == 1):
    print("Enter Document Name:")
    filename = input()
    f = open(filename, 'r')
    sent = ""
    for line in f:
        if line != '\n':
            sent += line

    f.close()
    print(sent)

elif (inp == 2):
    print("Enter Sentence:")
    sent = input()

else:
    sent = "If Delhi is the capital of India, then, what is the capital of China?"

nlp = spacy.load('en_core_web_sm', disable=['parser', 'ner'])

doc = nlp(sent)

print("Word\t\tLemma\t\tPOS\t\tTag")
print("-"*52)
for token in doc:
    print (str(token) + "\t\t" + str(token.lemma_) + "\t\t" + str(token.pos_) + "\t\t" + str(token.tag_))