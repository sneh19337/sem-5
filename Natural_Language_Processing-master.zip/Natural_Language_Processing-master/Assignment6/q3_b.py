import spacy

print("""Choose among the following: 
    1. Document
    2. Sentence
    3. Sample Sentence""")

inp = int(input())

if (inp == 1):
    print("Enter Document Name:")
    filename = input()
    f = open(filename, 'r')
    sent = ""
    for line in f:
        if line != '\n':
            sent += line

    f.close()
    print(sent)

elif (inp == 2):
    print("Enter Sentence:")
    sent = input()

else:
    sent = "If Delhi is the capital of India, then, what is the capital of China? Apple is looking at buying U.K. startup for $1 billion"

nlp = spacy.load('en_core_web_sm')

doc = nlp(sent)

print("Text\t\tStart\t\tEnd\t\tLabel")
print("-"*54)
for ent in doc.ents:
    print(str(ent.text) + "\t\t" + str(ent.start_char) + "\t\t" + str(ent.end_char) + "\t\t" + str(ent.label_))