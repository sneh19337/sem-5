# NLP-Course-Work
CSE 556 - Introduction to Natural Language Processing course work at IIIT Delhi

Assignment 1 - Edit Distance between two strings
Assignment 2 - Implementing NLTK sentence parser, paragraph parser, tokenizer, search using regex from scratch.
Assignment 3 - N-gram model for sentence generation
Assignment 4 - Hidden Markov Model for POS tags
