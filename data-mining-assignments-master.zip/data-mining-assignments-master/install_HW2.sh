#!/bin/bash

git clone https://github.com/navreeetkaur/data-mining-clustering.git
pip3 install -U numpy matplotlib sys random scipy scikit-learn itertools heapq time random