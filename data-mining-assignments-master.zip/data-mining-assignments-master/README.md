# data-mining-assignments

## Assignment submissions for course COL761(2018-19) at IIT Delhi

This repository contains the assignment statements and their respective submissions.
The following repositories contain full implementation of corresponding assignments:
- Assignment 1: ```https://github.com/navreeetkaur/frequent-pattern-mining```
- Assignment 2: ```https://github.com/navreeetkaur/clustering-algorithms```
- Assignment 3: ```https://github.com/navreeetkaur/graph-classification```
