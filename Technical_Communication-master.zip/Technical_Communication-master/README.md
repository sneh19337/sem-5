# Technical_Communication
My assignments for TComm course  [COM301A]  [IIIT-Delhi].
