## Assignment 2
Technical Report summarising 2-3 research papers.