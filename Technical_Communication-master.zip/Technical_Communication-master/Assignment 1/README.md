## Assignment 1
Summary of a recent "hot paper" or classic paper in Computer Science field.