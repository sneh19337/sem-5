# Ques 3
## Problem Statement
Implement linked list and all its operation and demonstrate with suitable
input/output operations.

![](https://img.shields.io/badge/Language-C-orange.svg)

## Instruction to run linkedlist

1. Compile and run `linkedlist.c` as a normal c program.
2. Various available operations will be provided on screen.

![](https://ForTheBadge.com/images/badges/built-with-love.svg)
