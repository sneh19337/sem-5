# computer-networks-assignments

[![Generic badge](https://img.shields.io/badge/SOCKET-PROGRAMMING-<BLUE>.svg)](https://shields.io/)

![](https://img.shields.io/badge/Language-C++-orange.svg)


Contains all the assignments and solutions for computer networks course in IIIT Allahabad.
Check the respective assignment folder for detailed information about the assignment and how to run it.


