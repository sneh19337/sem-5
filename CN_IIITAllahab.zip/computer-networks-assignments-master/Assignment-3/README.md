# Assignment 3

## Question 1
- Build a similar program as of the Assignment 2 but use Stream Services and determine the IP address of client as well.

## Question 2
- Build a program to facilitate Voice Chat between a Client and a Server.
