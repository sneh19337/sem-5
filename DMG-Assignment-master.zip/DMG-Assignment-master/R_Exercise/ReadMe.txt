Please Read Me Before Grading 

-> In all the questions data is directly downloaded from the web at runtime so make sure internet is working
-> For downloading data from the given url in some questions I have used a liabrary 'data.table'
-> For installing the above mentioned liabrary follow the below mentioned steps :-
	1 write this command on your R console :- install.packages('data.table')  
	2 Choose (HTTP mirror) option in HTTPS CRAN mirror
	3 Then choose india in HTTPS CRAN mirror
	4 Done 
		